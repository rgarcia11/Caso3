# InfracompCase2
Logistica Aeroportuaria.
