package clienteSinSeguridad;


public class MainPruebas {
	
	public final static int NUMBER_OF_TASKS=80; //400, 200  y 80
	
	public final static int GAP_BETWEEN_TASKS=100; //20, 40 y 100

	public static void main(String[] args)
	{
		for (int i=0;i<10;i++)
		{
			@SuppressWarnings("unused")
			Generator gen = new Generator(); 
			
			
		}
		
		
		
	}
	
}
